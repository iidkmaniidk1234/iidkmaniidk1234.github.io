'use strict';
const dns = require('node:dns').promises;
const ipaddr = require('ipaddr.js');
const cache = new Map();
function checkedHostname(raw) {
  if (typeof raw !== 'string' || raw.length > 253 || /[\s/@:#\[\]\\]/.test(raw)) throw new Error('Invalid host');
  const host = raw.toLowerCase().replace(/\.$/, '');
  if (!host.includes('.') || !/^[a-z0-9.-]+$/.test(host) || host.split('.').some(x => !x || x.startsWith('-') || x.endsWith('-'))) throw new Error('Invalid host');
  if (ipaddr.isValid(host) || host === 'bash.tv' || host.endsWith('.bash.tv') || host.endsWith('.onbash.tv') || host.endsWith('.local') || host.endsWith('.internal') || host.endsWith('.localhost') || host.endsWith('.test')) throw new Error('Private or app-service address blocked');
  return host;
}
async function publicIP(raw, lookup = dns.lookup) {
  const host = checkedHostname(raw);
  let entry = cache.get(host);
  if (!entry || entry.until < Date.now() || lookup !== dns.lookup) {
    const pending = lookup(host, {all: true}).then(list => {
      if (!list.length || list.some(x => !ipaddr.isValid(x.address) || ipaddr.process(x.address).range() !== 'unicast')) throw new Error('Non-public destination blocked');
      return (list.find(x => x.family === 4) || list[0]).address;
    });
    entry = {until: Date.now() + 30000, pending};
    if (lookup === dns.lookup) {
      if (cache.size >= 1000) cache.delete(cache.keys().next().value);
      cache.set(host, entry);
      pending.catch(() => { if (cache.get(host) === entry) cache.delete(host); });
    }
  }
  return entry.pending;
}
module.exports = {checkedHostname, publicIP};
