'use strict';
const assert = require('node:assert/strict');
const http = require('node:http');
const fs = require('node:fs');
const {chromium} = require('playwright');
const {checkedHostname, publicIP} = require('./network-policy');
const listen = (server, port) => new Promise(resolve => server.listen(port, '127.0.0.1', resolve));
const close = server => new Promise(resolve => server.close(resolve));
async function main() {
  for (const name of ['localhost', '127.0.0.1', '169.254.169.254', '[::1]', 'bash.tv', 'api.bash.tv', '3000-space.proxy.onbash.tv', 'example.com/path', 'user@example.com', 'fake.local', 'bad\u0000host.com']) assert.throws(() => checkedHostname(name));
  for (const address of ['127.0.0.1', '10.2.0.1', '169.254.169.254', '100.64.0.1', '::1', '::ffff:127.0.0.1', 'fd00::1', '224.0.0.1', '0.0.0.0']) await assert.rejects(publicIP('fixture.example', async () => [{address, family: address.includes(':') ? 6 : 4}]));
  await assert.rejects(publicIP('fixture.example', async () => [{address:'93.184.215.14',family:4},{address:'127.0.0.1',family:4}]));
  assert.equal(await publicIP('fixture.example', async () => [{address:'93.184.215.14',family:4}]), '93.184.215.14');
  console.log('PASS: public-address checks, mixed DNS answers, mapped IPv6, app-service and metadata blocks');
  // Only this isolated test process permits the loopback fixture. Production never does.
  const {server} = require('./server');
  const {server: wisp} = require('@mercuryworkshop/wisp-js/server');
  for (const type of [1,2]) {
    let n=0;const packets=[];
    await wisp.ServerStream.prototype.ws_to_tcp.call({stream_type:type,stream_id:7,packets_sent:0,send_buffer:{size:0,get:async()=>++n<=60?Buffer.from('x'):null},socket:{send:async()=>{}},conn:{ws:{send:async data=>packets.push(data)}},close:async()=>{}});
    assert.equal(packets.length,type===1?5:0);
    for (const packet of packets) {assert.equal(packet[0],3);assert.equal(packet.readUInt32LE(1),7);assert.equal(packet.readUInt32LE(5),24);}
  }
  console.log('PASS: repeated TCP credit replenishment beyond initial Wisp window; no TCP credit for UDP');
  wisp.options.dns_method = async host => { if (host === 'fixture.example' || host === 'other.example') return '127.0.0.1'; return publicIP(host); };
  wisp.options.allow_loopback_ips = true;
  wisp.options.port_whitelist = [80,443,3911];
  const bytes = fs.readFileSync(__dirname + '/test/fixture.webm');
  const html = `<!doctype html><html><head><meta charset="utf-8"><title>Native browser test</title><style>body{font:18px sans-serif;margin:20px}input{font-size:20px}section{height:1500px}video{width:320px;height:180px}</style></head><body><h1 id="title">On-device fixture</h1><form method="post" action="/submit"><input name="message" id="text" aria-label="Message"><button>Submit</button></form><a id="next" href="/next">Next page</a><a id="other" href="http://other.example:3911/">Other origin</a><video id="video" src="/clip.webm" controls preload="metadata"></video><button id="play" onclick="document.getElementById('video').play()">Play clip</button><p id="js"></p><script>document.getElementById('js').textContent='JavaScript works';if(location.hostname==='fixture.example')document.cookie='fixture=car; path=/';</script><section></section><p id="bottom">Bottom of page</p></body></html>`;
  const fixture = http.createServer((req,res) => {
    if (req.url === '/clip.webm') {
      const match = /^bytes=(\d+)-(\d*)$/.exec(req.headers.range || '');
      const start = match ? Number(match[1]) : 0, end = match && match[2] ? Math.min(bytes.length-1,Number(match[2])) : bytes.length-1;
      res.writeHead(match ? 206 : 200, {'Content-Type':'video/webm','Accept-Ranges':'bytes','Content-Length':end-start+1,...(match?{'Content-Range':`bytes ${start}-${end}/${bytes.length}`}:{})});res.end(bytes.subarray(start,end+1));return;
    }
    if (req.url.startsWith('/ping')) {res.writeHead(200,{'Content-Type':'text/plain','Cache-Control':'no-store'});res.end('pong');return;}
    if (req.url === '/submit') {let body='';req.on('data',b=>body+=b);req.on('end',()=>{res.writeHead(200,{'Content-Type':'text/html'});res.end('<!doctype html><h1 id="posted">'+ new URLSearchParams(body).get('message').replace(/[<>&]/g,'')+'</h1>');});return;}
    if (req.url === '/next') {res.writeHead(200,{'Content-Type':'text/html'});res.end('<!doctype html><h1 id="next-page">Next page works</h1>');return;}
    res.writeHead(200,{'Content-Type':'text/html','Cache-Control':'no-store'});res.end(html);
  });
  const parent = http.createServer((_q,res)=>{res.setHeader('Content-Type','text/html');res.end('<!doctype html><iframe id="preview" src="http://localhost:3910" style="position:fixed;inset:0;width:100%;height:100%;border:0"></iframe>');});
  let browser;
  try {
    await listen(fixture,3911); await listen(server,3910); await listen(parent,3912);
    browser = await chromium.launch({executablePath:process.env.CHROMIUM_PATH || '/usr/local/bin/chromium',args:['--no-sandbox','--disable-dev-shm-usage']});
    const context = await browser.newContext({viewport:{width:1100,height:760}});
    const page = await context.newPage();
    const errors = []; page.on('pageerror',e=>errors.push(e.message));
    page.on('console',m=>{if(m.type()==='error')console.log('BROWSER',m.text().slice(0,350));});
    let remoteInputs=0;page.on('request',r=>{if(r.url().includes('/api/action'))remoteInputs++;});
    await page.goto('http://127.0.0.1:3912');
    const shell = page.frameLocator('#preview');
    await shell.locator('#start-input').fill('http://fixture.example:3911/'); await shell.locator('#start-form button').click();
    const site = shell.frameLocator('#web-page');
    await site.locator('#title').waitFor({timeout:20000}).catch(async error=>{console.log('SHELL',await shell.locator('#status').innerText(),await shell.locator('#page-notice').innerText());console.log('FRAMES',page.frames().map(f=>f.url()));await page.screenshot({path:'/tmp/carbrowser-test-failure.png'});throw error;});
    assert.equal(await site.locator('#js').innerText(),'JavaScript works');
    const actualShell = page.frames().find(f=>f.url()==='http://localhost:3910/');
    assert.equal(await actualShell.evaluate(()=>crossOriginIsolated),false);
    assert.equal(await actualShell.evaluate(()=>typeof SharedArrayBuffer),'undefined');
    console.log('PASS: JavaScript and service worker inside a cross-site, non-isolated iframe without SharedArrayBuffer');
    const responses=await site.locator('body').evaluate(async()=>{let total=0;for(let i=0;i<90;i++){const r=await fetch('/ping?'+i);if(await r.text()==='pong')total++;}return total;});
    assert.equal(responses,90);console.log('PASS: 90 sequential real proxied requests without exhausting Wisp credit');
    const input = site.locator('#text'); const text='CarBrowser types directly on this device';
    const start=Date.now();await input.pressSequentially(text,{delay:2});const elapsed=Date.now()-start;
    assert.equal(await input.inputValue(),text);assert(elapsed<2000);assert.equal(remoteInputs,0);
    console.log(`PASS: native typing (${text.length} characters in ${elapsed} ms), no remote input batches`);
    await site.locator('#play').click();
    const before = await site.locator('#video').evaluate(v=>({time:v.currentTime,quality:v.getVideoPlaybackQuality()}));
    await page.waitForTimeout(3200);
    const after = await site.locator('#video').evaluate(v=>({time:v.currentTime,frames:v.getVideoPlaybackQuality().totalVideoFrames,dropped:v.getVideoPlaybackQuality().droppedVideoFrames,paused:v.paused,error:v.error?.code,audio:v.muted}));
    assert(!after.error);assert(!after.paused);assert(after.time-before.time>2);assert(after.frames>40);assert(after.dropped/after.frames<0.35);assert.equal(after.audio,false);
    console.log('PASS: real native video/audio playback',JSON.stringify(after));
    await site.locator('#bottom').scrollIntoViewIfNeeded();assert(await site.locator('#bottom').isVisible());
    await site.locator('#next').click();await site.locator('#next-page').waitFor();await shell.locator('#back').click();await site.locator('#title').waitFor();
    await site.locator('#text').fill('native form submission');await site.locator('form button').click();await site.locator('#posted').waitFor();assert.equal(await site.locator('#posted').innerText(),'native form submission');
    console.log('PASS: native scroll, links, history and POST forms');
    await shell.locator('#address').fill('http://fixture.example:3911/');await shell.locator('#address-form').evaluate(f=>f.requestSubmit());await site.locator('#title').waitFor();
    assert.match(await site.locator('body').evaluate(()=>document.cookie),/fixture=car/);
    await site.locator('#other').click();await site.locator('#title').waitFor();assert.match(await shell.locator('#address').inputValue(),/other.example/);assert.doesNotMatch(await site.locator('body').evaluate(()=>document.cookie),/fixture=car/);
    await shell.locator('#home').click();await shell.locator('#help').click();await shell.locator('#reset-session').click();await shell.locator('#toast').waitFor();
    assert.equal(await actualShell.evaluate(async()=>{const db=await new Promise((resolve,reject)=>{const req=indexedDB.open('__scramjet_controller');req.onsuccess=()=>resolve(req.result);req.onerror=reject;});return await new Promise(resolve=>{const r=db.transaction('state').objectStore('state').get('cookies');r.onsuccess=()=>resolve(r.result?.cookies||'');});}),'{}');
    console.log('PASS: website cookie handling and clear-data flow');
    await page.screenshot({path:'/tmp/carbrowser-native-desktop.png'});
    await page.setViewportSize({width:390,height:844});
    await actualShell.waitForFunction(()=>innerWidth===390 && innerHeight===844);
    await actualShell.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));
    await page.screenshot({path:'/tmp/carbrowser-native-phone.png'});
    assert.equal(await actualShell.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);
    assert.deepEqual(errors,[]);
    console.log('PASS: phone layout and no uncaught browser errors');
  } finally {
    await browser?.close(); await Promise.all([close(parent),close(server),close(fixture)]);
  }
}
main().catch(e=>{console.error(e);process.exitCode=1;});
