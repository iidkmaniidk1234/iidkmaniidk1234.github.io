'use strict';
// Work around wisp-js 0.5.2 sending CONTINUE only for UDP instead of TCP.
// Without fresh TCP credit, a reused connection stops after its initial window:
// busy pages hang and later video-range requests never leave the browser.
// Based on ServerStream.ws_to_tcp, Copyright Mercury Workshop contributors,
// LGPL-3.0-or-later; source: https://github.com/MercuryWorkshop/wisp-js
function installFlowControl(wisp) {
  const prototype = wisp.ServerStream.prototype;
  if (!prototype.ws_to_tcp.toString().includes('this.stream_type !== stream_types.UDP')) return false;
  prototype.ws_to_tcp = async function () {
    while (true) {
      const data = await this.send_buffer.get();
      if (data == null) break;
      await this.socket.send(data);
      this.packets_sent++;
      const size = wisp.options.send_buffer_size;
      if (this.stream_type !== 1 || this.packets_sent % Math.max(1, Math.floor(size / 2)) !== 0) continue;
      const packet = Buffer.alloc(9);
      packet[0] = 3; // Wisp CONTINUE: type, stream ID, available packet credit.
      packet.writeUInt32LE(this.stream_id, 1);
      packet.writeUInt32LE(Math.max(0, size - this.send_buffer.size), 5);
      await this.conn.ws.send(packet);
    }
    await this.close();
  };
  return true;
}
module.exports = {installFlowControl};
