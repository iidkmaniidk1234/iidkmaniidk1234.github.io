// Optional real-internet check. Not part of deterministic npm test.
const {chromium} = require('playwright');
(async () => {
  const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/local/bin/chromium',args:['--no-sandbox','--disable-dev-shm-usage']});
  try {
    const page=await browser.newPage({viewport:{width:1100,height:760}});
    const errors=[];page.on('pageerror',e=>errors.push(e.message.slice(0,300)));
    await page.goto(process.env.BASE_URL || 'http://localhost:3004');
    await page.locator('#start-input').fill('https://www.youtube.com/');await page.locator('#start-form button').click();
    const site=page.frameLocator('#web-page');
    const search=site.locator('input[name="search_query"]:visible').first();
    await search.waitFor({timeout:25000});await search.pressSequentially('car drifting',{delay:12});
    await search.press('Enter');
    await site.locator('ytd-video-renderer').first().waitFor({timeout:25000});
    console.log('SEARCH ADDRESS',await page.locator('#address').inputValue());
    console.log('SEARCH TEXT',(await site.locator('body').innerText()).slice(0,1500));
    await page.screenshot({path:'/tmp/carbrowser-youtube-search.png'});
    await page.locator('#address').fill('https://www.youtube.com/watch?v=aqz-KE-bpKQ');await page.locator('#address-form').evaluate(f=>f.requestSubmit());
    await site.locator('video').first().waitFor({timeout:25000});
    await page.waitForTimeout(5000);
    const video=site.locator('video').first();
    if(await video.evaluate(v=>v.paused)){const point=await page.locator('#web-page').evaluate(el=>{const v=el.contentDocument.querySelector('video'),b=Element.prototype.getBoundingClientRect.call(v),o=el.getBoundingClientRect();return{x:o.x+b.x+b.width/2,y:o.y+b.y+b.height/2};});await page.mouse.click(point.x,point.y);}
    await page.waitForTimeout(3500);
    console.log('VIDEO',await video.evaluate(v=>({time:v.currentTime,ready:v.readyState,paused:v.paused,error:v.error?.code,width:v.videoWidth,height:v.videoHeight,frames:v.getVideoPlaybackQuality().totalVideoFrames,dropped:v.getVideoPlaybackQuality().droppedVideoFrames})));
    console.log('VIDEO TEXT',(await site.locator('body').innerText()).slice(0,1600));
    console.log('UNCAUGHT',errors.slice(0,8));
    await page.screenshot({path:'/tmp/carbrowser-youtube-video.png'});
  } finally {await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1});
