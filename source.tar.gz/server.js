'use strict';
const http = require('node:http');
const path = require('node:path');
const express = require('express');
const {WebSocketServer} = require('ws');
const {server: wisp, logging} = require('@mercuryworkshop/wisp-js/server');
const {scramjetPath} = require('@mercuryworkshop/scramjet/path');
const {publicIP} = require('./network-policy');
require('./flow-control').installFlowControl(wisp);
const PORT = Number(process.env.PORT || 3004);
const origin = process.env.PUBLIC_ORIGIN || '';
const additionalOrigins = new Set((process.env.ADDITIONAL_ORIGINS || '').split(',').filter(Boolean).map(raw => {
  const url = new URL(raw); if (url.origin !== raw || url.protocol !== 'https:') throw new Error('Additional origins must be exact HTTPS origins.');
  return url.origin;
}));
const root = path.join(__dirname, 'public');
const app = express();
app.disable('x-powered-by');
app.use((req, res, next) => {
  res.set({'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer', 'Cache-Control': 'no-cache', 'Permissions-Policy': 'camera=(), microphone=(), geolocation=(), payment=()'});
  next();
});
app.get('/health', (_req, res) => res.json({ok: true, browser: 'device-rendered'}));
app.get('/source.tar.gz', (_req, res) => res.download(path.join(__dirname, 'source.tar.gz'), 'carbrowser-source.tar.gz'));
app.use('/scram/', express.static(scramjetPath, {maxAge: '1d'}));
for (const [prefix, name] of [['controller', 'scramjet-controller'], ['utils', 'scramjet-utils'], ['libcurl', 'libcurl-transport']]) {
  app.use('/' + prefix + '/', express.static(path.dirname(require.resolve('@mercuryworkshop/' + name)), {maxAge: '1d'}));
}
app.use(express.static(root));
app.use((_req, res) => res.status(404).type('text').send('This page does not exist. Go back to CarBrowser.'));
logging.set_level(logging.ERROR);
Object.assign(wisp.options, {
  allow_udp_streams: false, allow_tcp_streams: true,
  allow_direct_ip: false, allow_private_ips: false, allow_loopback_ips: false,
  port_whitelist: [80, 443],
  stream_limit_total: 64, stream_limit_per_host: 24,
  dns_method: publicIP, dns_ttl: 30, parse_real_ip: false,
  send_buffer_size: 24,
});
const server = http.createServer(app);
const relay = new WebSocketServer({noServer:true, maxPayload:262144, perMessageDeflate:false});
const connections = new Set();
const perIP = new Map();
server.on('upgrade', (req, socket, head) => {
  // Exact path and Origin checks keep other websites from using this as their relay.
  if (req.url !== '/wisp/') return socket.destroy();
  let requestOrigin;
  try { requestOrigin = new URL(req.headers.origin); } catch { return socket.destroy(); }
  const local = ['localhost', '127.0.0.1'].includes(requestOrigin.hostname);
  const preview = requestOrigin.protocol === 'https:' && requestOrigin.host === `3004-03h5y7dcpjamq7cl7zde9v7pa.proxy.onbash.tv`;
  if (origin ? requestOrigin.origin !== origin && !additionalOrigins.has(requestOrigin.origin) : !(local || preview || additionalOrigins.has(requestOrigin.origin))) return socket.destroy();
  const ip = socket.remoteAddress;
  if (connections.size >= 64 || (perIP.get(ip) || 0) >= 8) return socket.destroy();
  perIP.set(ip, (perIP.get(ip) || 0) + 1); connections.add(socket);
  socket.setNoDelay(true);
  socket.once('close', () => { connections.delete(socket); const n = perIP.get(ip) - 1; if (n) perIP.set(ip, n); else perIP.delete(ip); });
  relay.handleUpgrade(req, socket, head, async ws => {
    ws.binaryType = 'arraybuffer';
    let bytes = 0, windowStart = Date.now();
    ws.on('error', () => {});
    ws.on('message', data => {
      if (Date.now() - windowStart >= 1000) { windowStart = Date.now(); bytes = 0; }
      bytes += data.byteLength || data.length || 0;
      if (bytes > 4 * 1024 * 1024) ws.close(1008, 'Upload rate limit');
    });
    const connection = new wisp.ServerConnection(ws, '/wisp/', {wisp_version:req.headers['sec-websocket-protocol'] ? 2 : 1});
    try { await connection.setup(); await connection.run(); }
    catch { ws.close(); await connection.cleanup().catch(() => {}); }
  });
});
async function start() {
  // Public raw-network relays must never share a process/server with injected API keys.
  if (process.env.BASHTV_EGRESS_URL) {
    const r = await fetch(process.env.BASHTV_EGRESS_URL + '/');
    if (!r.ok) throw new Error('Cannot check relay isolation.');
    const info = await r.json();
    if (Array.isArray(info.secrets) ? info.secrets.length : Object.keys(info.secrets || {}).length) throw new Error('Run the public relay on a separate server without attached API keys.');
  }
  if (origin && (new URL(origin).origin !== origin || !origin.startsWith('https://'))) throw new Error('PUBLIC_ORIGIN must be the exact HTTPS site origin, without a trailing slash.');
  server.listen(PORT, '0.0.0.0', () => console.log(`CarBrowser device-rendered browser ready on port ${PORT}`));
}
if (require.main === module) start().catch(e => { console.error(e.message); process.exit(1); });
module.exports = {app, server, start};
