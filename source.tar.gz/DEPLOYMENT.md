# CarBrowser — standalone hosting

This is the new device-rendered version. The previous remote-Chromium application
is preserved separately in `/home/bashtv/app` and is not part of this deployment.
The new version has no server-side user accounts or saved browser profiles. The
relay forwards public web connections; anonymous website state stays in each
visitor's browser. It runs without a Bash parent/sign-in. Bash.js remains loaded
for preview integration and display-only public-link information.

## Temporary standalone demo

This session also runs a free, account-less Cloudflare Quick Tunnel at:
https://logos-generations-watson-duncan.trycloudflare.com

It is a **temporary test address**, not a registered CarBrowser domain or a
production deployment. It works only while the tunnel and sandbox remain running;
a restarted tunnel gets a different name. It has no uptime guarantee and is
limited to 200 in-flight requests. Nothing was purchased.
https://developers.cloudflare.com/tunnel/get-started/quick-tunnels/

The preview server explicitly allowlists this one extra HTTPS origin through
ADDITIONAL_ORIGINS. No wildcard origins or credentials are used. The production
Compose configuration does not enable this demo origin.

## Suggested address and budget (checked 3 November 2026)

- Suggested name: **getcarbrowser.com**. The .com registry returned no record
  (RDAP HTTP 404) when checked. This is NOT a reservation or a guarantee of
  availability, trademark clearance, or registrar pricing.
- `carbrowser.com` is already registered (registry RDAP HTTP 200).
- Domain registrar: Porkbun lists standard .com registration and renewal at
  **US$11.81/year**, before any applicable taxes or premium-name charges.
  https://porkbun.com/products/domains
- Starting host: DigitalOcean Basic Droplet, **1 vCPU / 2 GiB RAM / 2,000 GiB
  transfer**, listed at **US$12/month**. This is a small-pilot recommendation,
  not an unlimited public-video service or a performance guarantee.
  https://www.digitalocean.com/pricing/droplets
- Start with an Ubuntu Docker host in a region near the intended visitors.
  GPU hosting is not needed for the device-rendered version. Visitors decode
  video themselves; the server relays bytes. Network transfer is the likely
  scaling cost. Confirm proxy use under your host's current acceptable-use rules.
- Optional higher-headroom host: Basic **2 vCPU / 4 GiB**, listed at $24/month.
- Configure billing and transfer alerts. Alerts are NOT hard spending caps.
  Do not buy or provision anything before the owner approves the cost.

No domain, hosting account, server, DNS record or TLS certificate has been bought
or provisioned by this project. No public custom-domain deployment is claimed.

## Owner steps

1. Check the proposed domain in the registrar, review first-year AND renewal
   prices, and register it yourself if desired. Keep account/payment details out
   of chat. Enable 2FA on the registrar and host accounts.
2. Create a small VPS/Docker host. Prefer SSH keys over password login. Set a
   firewall allowing 80/443 publicly and SSH only from your trusted IP.
3. Upload this source folder to the server. It needs no Chromium, Playwright,
   Python, GPU, API keys or private credentials in production.
4. Set an A record for the chosen domain to the server's public IPv4. Do not add
   an AAAA record unless IPv6 is configured and tested. DNS changes may take time.
5. Copy `.env.example` to `.env` and set DOMAIN to the domain you actually own.
   Keep it as a hostname only (no scheme, path or trailing slash).
6. Install Docker Engine and the Compose plugin using Docker's official Ubuntu
   instructions: https://docs.docker.com/engine/install/ubuntu/
7. In this folder, run `docker compose up --build -d`.
8. Caddy obtains/renews HTTPS automatically. DNS must point to the server and
   ports 80/443 must be reachable for this to work.
9. Verify `https://YOUR-DOMAIN/health`, a proxied page, a POST form, mobile input,
   sound and a non-DRM video. Test from a second device outside your home network.
   Check error logs with `docker compose logs --tail=100`. Avoid access logs that
   record browsing paths or headers.

The finished address will be `https://YOUR-DOMAIN/`. **getcarbrowser.com is only a
proposal until registration, DNS, deployment and external checks are complete.**

## Operation, safety and limitations

- Run this relay on a separate host with **no space/provider API keys**, cloud
  roles, private services or other secrets. The process refuses to start when
  attached space secrets are visible. Do not expose the old hosted browser or
  its private session APIs under this origin.
- SSRF policy blocks private/loopback/link-local/metadata addresses, mixed public
  and private DNS answers, app-service domains, UDP and ports other than 80/443.
  The checked IP is the actual TCP destination, not a second unchecked lookup.
- Origins are checked against PUBLIC_ORIGIN. Connection, stream, message-size
  and upload-rate limits reduce abuse; they do not replace a production abuse
  program. Origin is not user authentication and non-browser clients can forge
  it. For a large public launch, add an edge challenge/rate limits, destination
  policy, a bandwidth cap/monitor and an abuse contact first. Review host terms.
- Native video removes screenshot encoding/display latency, but it cannot fix a
  slow origin, poor connection, broken site rewriting, CAPTCHAs or DRM. Treat the
  pinned alpha engine as experimental. Avoid sensitive accounts.
- Browser-local cookies/cache are not synchronized across devices or Bash accounts.
  People sharing a device/browser share this anonymous state until it is cleared.
- flow-control.js supplies an application-level TCP-credit fix for wisp-js 0.5.2.
  Without it, busy reused connections stopped after the initial packet window.
  Regression tests cover replenishment and 90 sequential real proxied requests.
- Main-menu car/stars stop rendering while browsing. No remote mouse/keyboard
  event batches or periodic browser-session sign-in checks are used here.

## GitHub Pages front end (not a complete backend deployment)

The verified public account is `iidkmaniidk1234`. Its expected user-site address is
`https://iidkmaniidk1234.github.io/`, using a repository named
`iidkmaniidk1234.github.io`. At preparation time the address returned 404 and no
public user-site repository was found. Nothing has been published to GitHub by
this session; no GitHub connection/token is attached. A username is not authority
to write to an account.

Run `npm run pages` to build `github-pages/` and
`public/carbrowser-github-pages.zip`. The builder uses Node and Python 3 (for ZIP
creation). It copies the complete static browser runtime locally and changes
only the Wisp address to the existing public relay. It includes source/licensing
files and a `.nojekyll` marker; it does not upload anything or create an account.
This is a ROOT user-site build, not a `/carbrowser/` project-path build.

The owner can create the public user-site repository, upload the ZIP's CONTENTS
with index.html at the root, commit to main, then select Settings > Pages >
Deploy from a branch > main > /(root) > Save. Do not overwrite an existing site
or repository without checking its contents. Wait for GitHub's successful Pages
deployment before claiming the address is live.

The relay must explicitly allow `https://iidkmaniidk1234.github.io` through
ADDITIONAL_ORIGINS. GitHub Pages itself cannot run Node or Wisp. The temporary
relay still goes offline when the sandbox/tunnel stops, and an institutional
network can block that connection even if GitHub Pages loads. A GitHub address
does not hide or remove that restriction.

## Development and checks

`npm ci`, then `npm start` (default port 3004). Production can set PORT and
PUBLIC_ORIGIN. `npm test` runs network-policy checks and isolated browser tests.
Tests need Chromium; set CHROMIUM_PATH if it is not at `/usr/local/bin/chromium`.
Test-only fixture overrides never apply to the running public server. The optional
`node site-smoke.js` checks real YouTube search/playback. Set BASE_URL to check a
public deployment instead of localhost. It depends on external site availability.
Docker/Compose has not been built/run inside this sandbox (Docker is unavailable);
validate the deployment on the chosen host before calling it production-ready.

Before distributing updates, run `npm run source` to refresh source.tar.gz.
The source link in Session & help serves that exact archive. See LICENSE and
public/NOTICE.txt for dependency licensing and upstream corresponding-source links.
