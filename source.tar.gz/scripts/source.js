'use strict';
const path = require('node:path');
const {execFileSync} = require('node:child_process');
const root = path.join(__dirname, '..');
// Explicit allowlist: never package credentials, .env, uploads or server logs.
const files = ['package.json','package-lock.json','server.js','network-policy.js','flow-control.js','public','scripts','test.js','site-smoke.js','test','LICENSE','DEPLOYMENT.md','Dockerfile','compose.yaml','Caddyfile','.env.example','.dockerignore'];
execFileSync('tar', ['--exclude=public/carbrowser-github-pages.zip', '-czf', path.join(root,'source.tar.gz'), '-C', root, ...files]);
console.log('Updated source.tar.gz (application, tests, deployment and licensing).');
