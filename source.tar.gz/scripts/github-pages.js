'use strict';
// Static user-site build: OWNER.github.io (root, not a project subdirectory).
// The relay remains external: GitHub Pages cannot run the Node/Wisp server.
const fs = require('node:fs');
const path = require('node:path');
const {execFileSync} = require('node:child_process');
const root = path.join(__dirname, '..');
const out = path.join(root, 'github-pages');
const archive = path.join(root, 'public/carbrowser-github-pages.zip');
const owner = process.env.PAGES_OWNER || 'iidkmaniidk1234';
if (!/^[a-z\d](?:[a-z\d-]{0,37}[a-z\d])?$/i.test(owner)) throw new Error('Invalid GitHub username.');
const relay = new URL(process.env.RELAY_URL || 'wss://logos-generations-watson-duncan.trycloudflare.com/wisp/');
if (relay.protocol !== 'wss:' || relay.username || relay.password || relay.search || relay.hash) throw new Error('Use a public wss:// relay without credentials.');
execFileSync(process.execPath, [path.join(root,'scripts/source.js')], {stdio:'inherit'});
fs.rmSync(out, {recursive:true, force:true}); fs.mkdirSync(out, {recursive:true});
// Do not copy generated archives back into themselves.
fs.cpSync(path.join(root,'public'), out, {recursive:true, filter:file=>!file.endsWith('carbrowser-github-pages.zip')});
const nativePath = path.join(out,'native.js');
let native = fs.readFileSync(nativePath,'utf8');
const old = "(location.protocol === 'https:' ? 'wss://' : 'ws://') + location.host + '/wisp/'";
if (native.split(old).length !== 2) throw new Error('Relay setting changed: update the static builder.');
native = native.replace(old, JSON.stringify(relay.href)); fs.writeFileSync(nativePath,native);
const assets = {
  scram: ['scramjet','scramjet.js','scramjet.js.map','scramjet.wasm'],
  controller: ['scramjet-controller','controller.api.js','controller.api.js.map','controller.inject.js','controller.inject.js.map','controller.sw.js','controller.sw.js.map'],
  utils: ['scramjet-utils','scramjet-utils.js','scramjet-utils.js.map'],
  libcurl: ['libcurl-transport','index.mjs'],
};
for (const [folder,[pkg,...files]] of Object.entries(assets)) {
  const source = folder==='scram' ? require('@mercuryworkshop/scramjet/path').scramjetPath : path.dirname(require.resolve('@mercuryworkshop/'+pkg));
  fs.mkdirSync(path.join(out,folder),{recursive:true});
  for (const file of files) fs.copyFileSync(path.join(source,file),path.join(out,folder,file));
}
fs.copyFileSync(path.join(root,'source.tar.gz'),path.join(out,'source.tar.gz'));
fs.copyFileSync(path.join(root,'LICENSE'),path.join(out,'LICENSE'));
fs.writeFileSync(path.join(out,'.nojekyll'),'');
fs.writeFileSync(path.join(out,'README.txt'),`CarBrowser - GitHub Pages upload\n\nTarget repository: ${owner}.github.io\nExpected address AFTER successful publication: https://${owner.toLowerCase()}.github.io/\n\n1. Create the public repository named ${owner}.github.io in YOUR GitHub account.\n2. Upload this folder's CONTENTS (index.html, folders, etc.), not this folder or its ZIP.\n3. Commit to main. Open Settings > Pages, choose Deploy from a branch, main, /(root), Save.\n4. Wait for GitHub's deployment to finish. GitHub shows the actual published address.\n\nNo GitHub login, token, or payment information is contained in these files.\nA username alone does not let the bot create a repository or publish on your behalf.\n\nIMPORTANT: GitHub Pages serves only static files. Browsing uses this external relay:\n${relay.href}\nIts server must explicitly allow https://${owner.toLowerCase()}.github.io as an Origin.\nThe current Cloudflare relay is temporary and stops when the sandbox/tunnel stops.\nA network that blocks the relay can still block browsing even if this front end loads.\nThis is not a complete permanent deployment and does not hide network traffic.\n\nSource and notices: source.tar.gz, NOTICE.txt, LICENSE.\n`);
execFileSync('python3', ['-c', 'import pathlib,sys,zipfile\nr=pathlib.Path(sys.argv[1])\nwith zipfile.ZipFile(sys.argv[2],"w",zipfile.ZIP_DEFLATED) as z:\n for f in sorted(r.rglob("*")):\n  if f.is_file(): z.write(f,f.relative_to(r).as_posix())\n', out, archive]);
console.log('Created GitHub Pages files for '+owner+' and public/carbrowser-github-pages.zip. This does NOT publish a website.');
