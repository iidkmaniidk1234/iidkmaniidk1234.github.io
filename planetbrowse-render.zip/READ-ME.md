# PlanetBrowse — free Render deployment

This prepares a stable `https://…onrender.com` address. It does NOT create a
Render service or publish anything by itself. Only the owner needs GitHub/Render
accounts. Visitors need neither an account nor PlanetBrowse waitlist approval.

## Upload two files

1. Download `planetbrowse-render.zip` from the bot's link and unzip it.
   It contains `planetbrowse-source.tar.gz`, `render.yaml` and this guide.
   Keep the `.tar.gz` file compressed; do not unzip or rename that inner file.
2. Open https://github.com/iidkmaniidk1234/CarBrowser/upload/main while signed in.
3. Upload BOTH files to the ROOT of `CarBrowser` and commit the change. Leave
   your separate `iidkmaniidk1234.github.io` repository alone.

The archive is the complete current source and browser runtimes, with the credit
“this was created by oliver matos”. It excludes credentials, visitor records,
models, saved images/videos, logs and browsing history. Source code is AGPL-3.0.

## Create the free web service

1. Sign in at https://dashboard.render.com using GitHub.
2. Create a **Blueprint**, connect `iidkmaniidk1234/CarBrowser`, and let Render
   read `render.yaml` from the main branch.
3. Confirm that the only service is the **Free** `planetbrowse` web service.
   There must be no paid database, disk, worker or other paid resource.
4. Use a workspace WITHOUT a payment method so free-usage exhaustion suspends
   rather than bills. If Render asks for payment, a deposit, an upgrade, or
   paid identity verification, STOP and tell the bot. No purchase is authorized.
5. Deploy. When the status is Live, open the assigned HTTPS `onrender.com` URL.
   That is the address to share, not a Bash invite or temporary tunnel.

The build extracts the archive, installs pinned production dependencies and
starts Node 24. It uses Render's own PORT and RENDER_EXTERNAL_URL, public browsing
mode, and exact-origin checks automatically. No tunnel, API key, Bash identity,
credit-card entry, always-on ping or extra account for visitors is needed.

## Free-plan limits — important

Render's current docs say free services sleep after 15 idle minutes, may take
about a minute to wake, share 750 instance-hours per workspace/month, and have
bandwidth/build limits. They can also be suspended for unusually high
service-initiated public-internet traffic. Browser proxy traffic can trigger
these limits. This is a stable address, not a promise of forever hosting,
unlimited browsing, provider approval, or acceptance on every school's network.
Do not create extra accounts/services, fake traffic or keep-alive jobs to evade
limits. If the provider disallows or suspends this use, stop; do not disguise it.

## Local AI and online video

The lightweight deployment redirects only the app's exact pinned public model
files to their original Hugging Face/GitHub publishers. It does not store or
relay gigabytes of model weights through Render. Downloads still require the
existing explicit device consent. No prompts, chats, images or browser contents
go with these model downloads; local inference is still local and needs the
same hardware. Publisher CORS/range access, network access and browser cache
space are required. Real local image inference remains unverified on this VM.

Video still uses the official free LTX demo, with explicit selected-media
consent. Optional server mode shares the Render server's anonymous free quota,
which may differ from the sandbox's quota; it has no paid fallback or quota
workaround. Free hosting does not guarantee that the video provider accepts
requests or that a particular device/network can connect.

Owner inbox operations remain signed-owner-only. Old sandbox approval records
are NOT uploaded. Render's free filesystem is ephemeral, so don't treat it as
persistent account storage. Public browsing needs no approval records anyway.

Sources checked: https://render.com/docs/free and
https://render.com/acceptable-use . No live Render deployment is claimed until
its actual URL, TLS, guest browsing and Wisp connection are checked.
